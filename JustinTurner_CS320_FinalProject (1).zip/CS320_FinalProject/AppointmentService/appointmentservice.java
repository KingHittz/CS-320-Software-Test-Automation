/**
 * AppointmentService.java - Service for Managing Appointments
 * Author: Justin Turner
 * CS 320 - Module Five Milestone
 */

import java.util.HashMap;
import java.util.Map;
import java.util.Date;

public class AppointmentService {
    // In-memory data structure to store appointments
    private Map<String, Appointment> appointments;

    public AppointmentService() {
        this.appointments = new HashMap<>();
    }

    // Add a new appointment with unique ID
    public boolean addAppointment(String appointmentId, Date appointmentDate, String description) {
        // Check if appointment ID already exists
        if (appointments.containsKey(appointmentId)) {
            return false;
        }
        
        try {
            Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
            appointments.put(appointmentId, newAppointment);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // Delete appointment by ID
    public boolean deleteAppointment(String appointmentId) {
        if (appointments.containsKey(appointmentId)) {
            appointments.remove(appointmentId);
            return true;
        }
        return false;
    }

    // Get appointment by ID (helper method for testing)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}