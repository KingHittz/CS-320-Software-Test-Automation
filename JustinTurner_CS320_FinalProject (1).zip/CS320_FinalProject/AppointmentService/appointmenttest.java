/**
 * AppointmentTest.java - Unit Tests for Appointment Object
 * Author: Justin Turner
 * CS 320 - Module Five Milestone
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    // Test creating a valid appointment
    @Test
    public void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Annual checkup");
        
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Annual checkup", appointment.getDescription());
    }

    // Test that appointment ID cannot be null
    @Test
    public void testAppointmentIdNotNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Test description");
        });
    }

    // Test that appointment ID cannot be longer than 10 characters
    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Test description");
        });
    }

    // Test that appointment date cannot be null
    @Test
    public void testAppointmentDateNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Test description");
        });
    }

    // Test that appointment date cannot be in the past
    @Test
    public void testAppointmentDateNotInPast() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date pastDate = cal.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Test description");
        });
    }

    // Test that description cannot be null
    @Test
    public void testDescriptionNotNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    // Test that description cannot be longer than 50 characters
    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDescription = "This is a very long description that exceeds fifty characters";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, longDescription);
        });
    }

    // Test updating appointment date
    @Test
    public void testUpdateAppointmentDate() {
        Date futureDate1 = new Date(System.currentTimeMillis() + 100000);
        Date futureDate2 = new Date(System.currentTimeMillis() + 200000);
        Appointment appointment = new Appointment("12345", futureDate1, "Test");
        
        appointment.setAppointmentDate(futureDate2);
        assertEquals(futureDate2, appointment.getAppointmentDate());
    }

    // Test updating description
    @Test
    public void testUpdateDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Original");
        
        appointment.setDescription("Updated description");
        assertEquals("Updated description", appointment.getDescription());
    }

    // Test that setter validates appointment date
    @Test
    public void testSetAppointmentDateValidation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Test");
        
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date pastDate = cal.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate);
        });
    }
}