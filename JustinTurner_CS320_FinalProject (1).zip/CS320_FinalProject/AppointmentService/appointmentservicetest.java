/**
 * AppointmentServiceTest.java - Unit Tests for Appointment Service
 * Author: Justin Turner
 * CS 320 - Module Five Milestone
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {
    
    private AppointmentService service;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
    }

    // Test adding a valid appointment
    @Test
    public void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        boolean result = service.addAppointment("12345", futureDate, "Doctor appointment");
        
        assertTrue(result);
        assertNotNull(service.getAppointment("12345"));
    }

    // Test that appointment ID must be unique
    @Test
    public void testAddAppointmentWithDuplicateId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        service.addAppointment("12345", futureDate, "First appointment");
        
        boolean result = service.addAppointment("12345", futureDate, "Second appointment");
        assertFalse(result);
    }

    // Test adding appointment with null ID
    @Test
    public void testAddAppointmentNullId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        boolean result = service.addAppointment(null, futureDate, "Test");
        
        assertFalse(result);
    }

    // Test adding appointment with ID too long
    @Test
    public void testAddAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        boolean result = service.addAppointment("12345678901", futureDate, "Test");
        
        assertFalse(result);
    }

    // Test adding appointment with null date
    @Test
    public void testAddAppointmentNullDate() {
        boolean result = service.addAppointment("12345", null, "Test");
        assertFalse(result);
    }

    // Test adding appointment with past date
    @Test
    public void testAddAppointmentPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date pastDate = cal.getTime();
        
        boolean result = service.addAppointment("12345", pastDate, "Test");
        assertFalse(result);
    }

    // Test adding appointment with null description
    @Test
    public void testAddAppointmentNullDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        boolean result = service.addAppointment("12345", futureDate, null);
        
        assertFalse(result);
    }

    // Test adding appointment with description too long
    @Test
    public void testAddAppointmentDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDesc = "This is a description that is way too long and exceeds the fifty character limit";
        
        boolean result = service.addAppointment("12345", futureDate, longDesc);
        assertFalse(result);
    }

    // Test deleting an appointment
    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        service.addAppointment("12345", futureDate, "Test appointment");
        
        boolean result = service.deleteAppointment("12345");
        assertTrue(result);
        assertNull(service.getAppointment("12345"));
    }

    // Test deleting appointment that doesn't exist
    @Test
    public void testDeleteNonexistentAppointment() {
        boolean result = service.deleteAppointment("99999");
        assertFalse(result);
    }

    // Test adding multiple appointments
    @Test
    public void testAddMultipleAppointments() {
        Date futureDate1 = new Date(System.currentTimeMillis() + 100000);
        Date futureDate2 = new Date(System.currentTimeMillis() + 200000);
        
        service.addAppointment("001", futureDate1, "First appointment");
        service.addAppointment("002", futureDate2, "Second appointment");
        
        assertNotNull(service.getAppointment("001"));
        assertNotNull(service.getAppointment("002"));
    }
}