/**
 * ContactTest.java - Unit Tests for Contact Object
 * Author: Justin Turner
 * CS 320 - Module Three Milestone
 */

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    // Test data constants
    private static final String TEST_FIRST_NAME = "Justin"; 
    private static final String TEST_LAST_NAME = "Turner";
    private static final String VALID_PHONE = "5551234567";
    private static final String VALID_ADDRESS = "123 SNHU Drive";

    @Test
    @DisplayName("Should successfully create contact with valid parameters")
    void testCreateValidContact() {
        // Test valid contact creation
        Contact contact = new Contact("CONT001", TEST_FIRST_NAME, TEST_LAST_NAME, 
                                    VALID_PHONE, VALID_ADDRESS);
        
        // Verify fields
        assertEquals("CONT001", contact.getContactId());
        assertEquals(TEST_FIRST_NAME, contact.getFirstName());
        assertEquals(TEST_LAST_NAME, contact.getLastName());
        assertEquals(VALID_PHONE, contact.getPhone());
        assertEquals(VALID_ADDRESS, contact.getAddress());
    }

    @Test
    @DisplayName("Should reject null contact ID")
    void testNullContactId() {
        // Null ID should fail
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, TEST_FIRST_NAME, TEST_LAST_NAME, VALID_PHONE, VALID_ADDRESS);
        });
        assertTrue(exception.getMessage().contains("Contact ID"));
    }

    @Test
    @DisplayName("Should reject contact ID longer than 10 characters")
    void testContactIdTooLong() {
        // ID too long should fail
        String longId = "THISISTOOLONG"; // 13 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(longId, TEST_FIRST_NAME, TEST_LAST_NAME, VALID_PHONE, VALID_ADDRESS);
        });
    }

    @Test
    @DisplayName("Should reject empty contact ID")
    void testEmptyContactId() {
        // Empty ID should fail
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("", TEST_FIRST_NAME, TEST_LAST_NAME, VALID_PHONE, VALID_ADDRESS);
        });
    }

    @Test
    @DisplayName("Should reject invalid phone number formats")
    void testInvalidPhoneNumbers() {
        // Too short
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TEST1", TEST_FIRST_NAME, TEST_LAST_NAME, "123456", VALID_ADDRESS);
        });
        
        // Too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TEST2", TEST_FIRST_NAME, TEST_LAST_NAME, "12345678901", VALID_ADDRESS);
        });
        
        // Contains letters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TEST3", TEST_FIRST_NAME, TEST_LAST_NAME, "555CALL123", VALID_ADDRESS);
        });
        
        // Null phone
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TEST4", TEST_FIRST_NAME, TEST_LAST_NAME, null, VALID_ADDRESS);
        });
    }

    @Test
    @DisplayName("Should successfully update all mutable fields")
    void testUpdateContactFields() {
        // Create contact
        Contact contact = new Contact("UPD001", "Original", "Name", "1111111111", "Old Address");
        
        // Update fields
        contact.setFirstName(TEST_FIRST_NAME);
        contact.setLastName(TEST_LAST_NAME);
        contact.setPhone("9876543210");
        contact.setAddress("456 College Boulevard");

        // Verify updates
        assertEquals(TEST_FIRST_NAME, contact.getFirstName());
        assertEquals(TEST_LAST_NAME, contact.getLastName());
        assertEquals("9876543210", contact.getPhone());
        assertEquals("456 College Boulevard", contact.getAddress());
        
        // ID should not change
        assertEquals("UPD001", contact.getContactId());
    }

    @Test
    @DisplayName("Should reject updates with invalid data")
    void testInvalidUpdates() {
        // Create valid contact
        Contact contact = new Contact("VAL001", TEST_FIRST_NAME, TEST_LAST_NAME, 
                                    VALID_PHONE, VALID_ADDRESS);
        
        // Test invalid updates
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(""));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ThisNameIsTooLong"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("InvalidPhone"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123"));
        
        // Values should remain unchanged
        assertEquals(TEST_FIRST_NAME, contact.getFirstName());
        assertEquals(VALID_PHONE, contact.getPhone());
    }

    @Test
    @DisplayName("Should handle boundary cases correctly")
    void testBoundaryCases() {
        // Test maximum length values
        String maxLengthId = "1234567890"; // 10 chars
        String maxLengthName = "Maximilian"; // 10 chars
        String maxLengthAddr = "123456789012345678901234567890"; // 30 chars
        
        // Should pass with max lengths
        assertDoesNotThrow(() -> {
            Contact contact = new Contact(maxLengthId, maxLengthName, "Smith", 
                                        VALID_PHONE, maxLengthAddr);
            
            assertEquals(maxLengthId, contact.getContactId());
            assertEquals(maxLengthName, contact.getFirstName());
            assertEquals(maxLengthAddr, contact.getAddress());
        });
    }
}