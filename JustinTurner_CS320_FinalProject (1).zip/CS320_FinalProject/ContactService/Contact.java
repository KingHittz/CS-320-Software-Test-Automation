/**
 * Contact.java - Contact Object for Mobile Application
 * Author: Justin Turner
 * CS 320 - Module Three Milestone
 */

public class Contact {
    // Contact ID - immutable after creation
    private final String contactId;
    
    // Contact fields - can be updated
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Creates new contact with validation
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate contact ID - max 10 characters, not null
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
        
        // Validate first name - max 10 characters, not null
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        
        // Validate last name - max 10 characters, not null
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        
        // Validate phone - exactly 10 digits, not null
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        
        // Validate address - max 30 characters, not null
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }

        // Set fields
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Getters
    public String getContactId() { 
        return contactId; 
    }
    
    public String getFirstName() { 
        return firstName; 
    }
    
    public String getLastName() { 
        return lastName; 
    }
    
    public String getPhone() { 
        return phone; 
    }
    
    public String getAddress() { 
        return address; 
    }

    /**
     * Updates first name with validation
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }

    /**
     * Updates last name with validation
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    /**
     * Updates phone with validation
     */
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.phone = phone;
    }

    /**
     * Updates address with validation
     */
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}