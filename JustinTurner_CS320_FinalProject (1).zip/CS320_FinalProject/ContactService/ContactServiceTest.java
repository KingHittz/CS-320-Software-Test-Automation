public class ContactServiceTest {

    private ContactService contactService;
    
    // Test constants
    private static final String JUSTIN_ID = "JT001";
    private static final String JUSTIN_FIRST = "Justin";
    private static final String JUSTIN_LAST = "Turner";
    private static final String JUSTIN_PHONE = "5551234567";
    private static final String JUSTIN_ADDRESS = "123 SNHU Drive";
    
    private static final String FRIEND_ID = "JT002";
    private static final String FRIEND_FIRST = "TEST";
    private static final String FRIEND_LAST = "TEST";
    private static final String FRIEND_PHONE = "5559876543";
    private static final String FRIEND_ADDRESS = "123 University Ave";

    /**
     * Initialize fresh service before each test
     /**
 * ContactServiceTest.java - Unit Tests for Contact Service
 * Author: Justin Turner
 * CS 320 - Module Three Milestone
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;
    
    // Test constants using Justin Turner's information for personalized testing
    private static final String JUSTIN_ID = "JT001";
    private static final String JUSTIN_FIRST = "Justin";
    private static final String JUSTIN_LAST = "Turner";
    private static final String JUSTIN_PHONE = "5551234567";
    private static final String JUSTIN_ADDRESS = "123 SNHU Drive";
    
    // Additional test contact for multi-contact scenarios
    private static final String FRIEND_ID = "JT002";
    private static final String FRIEND_FIRST = "TEST";
    private static final String FRIEND_LAST = "TEST";
    private static final String FRIEND_PHONE = "5559876543";
    private static final String FRIEND_ADDRESS = "123 University Ave";

    /**
     * Initialize fresh service before each test
     */
    @BeforeEach
    void initializeTestEnvironment() {
        contactService = new ContactService();
    }

    @Test
    @DisplayName("Successfully add Justin Turner contact to service")
    void testAddJustinContact() {
        // Add contact
        Contact justinContact = new Contact(JUSTIN_ID, JUSTIN_FIRST, JUSTIN_LAST, 
                                          JUSTIN_PHONE, JUSTIN_ADDRESS);
        
        contactService.addContact(justinContact);
        
        // Verify addition
        assertEquals(1, contactService.getContactCount());
        assertTrue(contactService.contactExists(JUSTIN_ID));
    }

    @Test
    @DisplayName("Prevent duplicate contact IDs from being added")
    void testPreventDuplicateContactIds() {
        // Create contacts with same ID
        Contact original = new Contact(JUSTIN_ID, JUSTIN_FIRST, JUSTIN_LAST, 
                                     JUSTIN_PHONE, JUSTIN_ADDRESS);
        Contact duplicate = new Contact(JUSTIN_ID, "John", "Smith", 
                                      "5555555555", "789 Different St");
        
        contactService.addContact(original);
        
        // Duplicate should fail
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(duplicate);
        });
        
        assertTrue(exception.getMessage().contains("already exists"));
        assertEquals(1, contactService.getContactCount());
    }

    @Test
    @DisplayName("Successfully remove Justin's contact from service")
    void testDeleteJustinContact() {
        // Add then delete contact
        Contact justinContact = new Contact(JUSTIN_ID, JUSTIN_FIRST, JUSTIN_LAST, 
                                          JUSTIN_PHONE, JUSTIN_ADDRESS);
        
        contactService.addContact(justinContact);
        assertEquals(1, contactService.getContactCount());
        
        contactService.deleteContact(JUSTIN_ID);
        
        // Verify deletion
        assertEquals(0, contactService.getContactCount());
        assertFalse(contactService.contactExists(JUSTIN_ID));
    }

    @Test
    @DisplayName("Handle deletion of non-existent contact gracefully")
    void testDeleteNonExistentContact() {
        // Delete non-existent should fail
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("MISSING");
        });
        
        assertTrue(exception.getMessage().contains("No contact found"));
    }

    @Test
    @DisplayName("Update all fields for Justin Turner contact")
    void testUpdateJustinContactInformation() {
        // Add contact with placeholder values
        Contact justinContact = new Contact(JUSTIN_ID, "Original", "Name", 
                                          "1111111111", "Old Address");
        contactService.addContact(justinContact);

        // Update all fields
        contactService.updateFirstName(JUSTIN_ID, JUSTIN_FIRST);
        contactService.updateLastName(JUSTIN_ID, JUSTIN_LAST);
        contactService.updatePhone(JUSTIN_ID, JUSTIN_PHONE);
        contactService.updateAddress(JUSTIN_ID, "789 New Student Housing");

        // Verify updates
        assertEquals(JUSTIN_FIRST, justinContact.getFirstName());
        assertEquals(JUSTIN_LAST, justinContact.getLastName());
        assertEquals(JUSTIN_PHONE, justinContact.getPhone());
        assertEquals("789 New Student Housing", justinContact.getAddress());
        assertEquals(JUSTIN_ID, justinContact.getContactId());
    }

    @Test
    @DisplayName("Handle updates to non-existent contacts")
    void testUpdateNonExistentContact() {
        // All updates should fail for missing contact
        assertThrows(IllegalArgumentException.class, () -> 
            contactService.updateFirstName("MISSING", "Test"));
        assertThrows(IllegalArgumentException.class, () -> 
            contactService.updateLastName("MISSING", "Test"));
        assertThrows(IllegalArgumentException.class, () -> 
            contactService.updatePhone("MISSING", "5555555555"));
        assertThrows(IllegalArgumentException.class, () -> 
            contactService.updateAddress("MISSING", "Test Address"));
    }

    @Test
    @DisplayName("Manage multiple contacts including Justin and friends")
    void testMultipleContactManagement() {
        // Add two contacts
        Contact justinContact = new Contact(JUSTIN_ID, JUSTIN_FIRST, JUSTIN_LAST, 
                                          JUSTIN_PHONE, JUSTIN_ADDRESS);
        Contact friendContact = new Contact(FRIEND_ID, FRIEND_FIRST, FRIEND_LAST, 
                                          FRIEND_PHONE, FRIEND_ADDRESS);

        contactService.addContact(justinContact);
        contactService.addContact(friendContact);

        assertEquals(2, contactService.getContactCount());
        assertTrue(contactService.contactExists(JUSTIN_ID));
        assertTrue(contactService.contactExists(FRIEND_ID));

        // Update one contact
        contactService.updatePhone(JUSTIN_ID, "5552468101");
        assertEquals("5552468101", justinContact.getPhone());
        assertEquals(FRIEND_PHONE, friendContact.getPhone());

        // Delete one contact
        contactService.deleteContact(FRIEND_ID);
        assertEquals(1, contactService.getContactCount());
        assertTrue(contactService.contactExists(JUSTIN_ID));
        assertFalse(contactService.contactExists(FRIEND_ID));
    }

    @Test
    @DisplayName("Reject null contact additions")
    void testNullContactHandling() {
        // Null contact should fail
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(null);
        });
        
        assertTrue(exception.getMessage().contains("Cannot add null contact"));
    }

    @Test
    @DisplayName("Validate contact existence checking")
    void testContactExistenceValidation() {
        // Test existence checks
        assertFalse(contactService.contactExists(null));
        assertFalse(contactService.contactExists("NONEXISTENT"));
        
        Contact testContact = new Contact(JUSTIN_ID, JUSTIN_FIRST, JUSTIN_LAST, 
                                        JUSTIN_PHONE, JUSTIN_ADDRESS);
        contactService.addContact(testContact);
        
        assertTrue(contactService.contactExists(JUSTIN_ID));
    }
}