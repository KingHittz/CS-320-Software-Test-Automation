/**
 * ContactService.java - Contact Management Service
 * Author: Justin Turner
 * CS 320 - Module Three Milestone
 */

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class ContactService {
    // HashMap for O(1) contact lookups
    private final Map<String, Contact> contactDatabase = new HashMap<>();

    /**
     * Adds new contact with duplicate prevention
     */
    public void addContact(Contact contact) {
        // Check for null
        if (contact == null) {
            throw new IllegalArgumentException("JT_ERROR: Cannot add null contact");
        }
        
        String contactId = contact.getContactId();
        
        // Check for duplicates
        if (contactDatabase.containsKey(contactId)) {
            throw new IllegalArgumentException("JT_ERROR: Contact with ID '" + contactId + "' already exists");
        }
        
        contactDatabase.put(contactId, contact);
    }

    /**
     * Removes contact by ID
     */
    public void deleteContact(String contactId) {
        validateContactExists(contactId);
        contactDatabase.remove(contactId);
    }

    /**
     * Updates contact first name
     */
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = retrieveContact(contactId);
        contact.setFirstName(firstName);
    }

    /**
     * Updates contact last name
     */
    public void updateLastName(String contactId, String lastName) {
        Contact contact = retrieveContact(contactId);
        contact.setLastName(lastName);
    }

    /**
     * Updates contact phone
     */
    public void updatePhone(String contactId, String phone) {
        Contact contact = retrieveContact(contactId);
        contact.setPhone(phone);
    }

    /**
     * Updates contact address
     */
    public void updateAddress(String contactId, String address) {
        Contact contact = retrieveContact(contactId);
        contact.setAddress(address);
    }

    // Gets contact for internal use
    private Contact retrieveContact(String contactId) {
        validateContactExists(contactId);
        return contactDatabase.get(contactId);
    }

    // Validates contact exists
    private void validateContactExists(String contactId) {
        if (contactId == null || !contactDatabase.containsKey(contactId)) {
            throw new IllegalArgumentException("JT_ERROR: No contact found with ID '" + contactId + "'");
        }
    }

    /**
     * Returns contact count
     */
    public int getContactCount() {
        return contactDatabase.size();
    }

    /**
     * Checks if contact exists
     */
    public boolean contactExists(String contactId) {
        return contactId != null && contactDatabase.containsKey(contactId);
    }
}