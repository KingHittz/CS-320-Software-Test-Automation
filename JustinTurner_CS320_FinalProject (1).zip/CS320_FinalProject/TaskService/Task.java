/*
 * Author: Justin Turner
 * Course: CS 320 - Software Test Automation & QA
 * Module Four Milestone - Task Service
 * File: Task.java
 * Description: Task class that represents a task object with ID, name, and description
 */

public class Task {
    // Private fields to store task data
    private final String taskId;  // Final because ID cannot be updated
    private String name;
    private String description;
    
    /*
     * Constructor for creating a new Task object
     * @param taskId - unique identifier for the task (max 10 chars, not null)
     * @param name - task name (max 20 chars, not null)
     * @param description - task description (max 50 chars, not null)
     * @throws IllegalArgumentException if any parameter violates requirements
     */
    public Task(String taskId, String name, String description) {
        // Validate task ID requirements
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null and must be 10 characters or less");
        }
        
        // Validate name requirements
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less");
        }
        
        // Validate description requirements
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less");
        }
        
        // Set the fields after validation
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }
    
    /*
     * Getter for task ID
     * @return the task ID string
     */
    public String getTaskId() {
        return taskId;
    }
    
    /*
     * Getter for task name
     * @return the task name string
     */
    public String getName() {
        return name;
    }
    
    /*
     * Setter for task name with validation
     * @param name - new name for the task (max 20 chars, not null)
     * @throws IllegalArgumentException if name violates requirements
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less");
        }
        this.name = name;
    }
    
    /*
     * Getter for task description
     * @return the task description string
     */
    public String getDescription() {
        return description;
    }
    
    /*
     * Setter for task description with validation
     * @param description - new description for the task (max 50 chars, not null)
     * @throws IllegalArgumentException if description violates requirements
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less");
        }
        this.description = description;
    }
}