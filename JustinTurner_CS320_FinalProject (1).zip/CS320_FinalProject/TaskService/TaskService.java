/*
 * Author: Justin Turner
 * Course: CS 320 - Software Test Automation & QA
 * Module Four Milestone - Task Service
 * File: TaskService.java
 * Description: Service class for managing Task objects with add, update, and delete operations
 */

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // In-memory storage for tasks using HashMap for fast lookups by ID
    private Map<String, Task> tasks;
    
    /*
     * Constructor initializes the task storage
     */
    public TaskService() {
        tasks = new HashMap<>();
    }
    
    /*
     * Adds a new task to the service
     * @param task - Task object to be added
     * @throws IllegalArgumentException if task is null or ID already exists
     */
    public void addTask(Task task) {
        // Check if task object is null
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        
        // Check if task ID already exists (must be unique)
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        
        // Add the task to storage
        tasks.put(task.getTaskId(), task);
    }
    
    /*
     * Deletes a task from the service by task ID
     * @param taskId - ID of the task to delete
     * @throws IllegalArgumentException if task ID is null or doesn't exist
     */
    public void deleteTask(String taskId) {
        // Check if task ID is null
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null");
        }
        
        // Check if task exists before attempting to delete
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        
        // Remove the task from storage
        tasks.remove(taskId);
    }
    
    /*
     * Updates the name of an existing task
     * @param taskId - ID of the task to update
     * @param newName - new name for the task
     * @throws IllegalArgumentException if task ID is null, doesn't exist, or newName is invalid
     */
    public void updateTaskName(String taskId, String newName) {
        // Check if task ID is null
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null");
        }
        
        // Find the task to update
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        
        // Update the task name (validation happens in Task.setName())
        task.setName(newName);
    }
    
    /*
     * Updates the description of an existing task
     * @param taskId - ID of the task to update
     * @param newDescription - new description for the task
     * @throws IllegalArgumentException if task ID is null, doesn't exist, or newDescription is invalid
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        // Check if task ID is null
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null");
        }
        
        // Find the task to update
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        
        // Update the task description (validation happens in Task.setDescription())
        task.setDescription(newDescription);
    }
    
    /*
     * Retrieves a task by ID (useful for testing)
     * @param taskId - ID of the task to retrieve
     * @return Task object or null if not found
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
    
    /*
     * Gets the current number of tasks (useful for testing)
     * @return number of tasks in the service
     */
    public int getTaskCount() {
        return tasks.size();
    }
}