/*
 * Author: Justin Turner
 * Course: CS 320 - Software Test Automation & QA
 * Module Four Milestone - Task Service
 * File: TaskServiceTest.java
 * Description: JUnit tests for the TaskService class to verify all service requirements
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    
    private TaskService taskService;
    
    /*
     * Set up a fresh TaskService instance before each test
     */
    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }
    
    /*
     * Test successful addition of a task
     */
    @Test
    public void testAddTaskSuccess() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertEquals(1, taskService.getTaskCount());
        assertEquals(task, taskService.getTask("12345"));
    }
    
    /*
     * Test adding multiple tasks with unique IDs
     */
    @Test
    public void testAddMultipleTasks() {
        Task task1 = new Task("12345", "Task One", "First task");
        Task task2 = new Task("67890", "Task Two", "Second task");
        
        taskService.addTask(task1);
        taskService.addTask(task2);
        
        assertEquals(2, taskService.getTaskCount());
        assertEquals(task1, taskService.getTask("12345"));
        assertEquals(task2, taskService.getTask("67890"));
    }
    
    /*
     * Test that adding a null task throws exception
     */
    @Test
    public void testAddNullTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(null);
        });
    }
    
    /*
     * Test that adding tasks with duplicate IDs throws exception
     */
    @Test
    public void testAddTaskWithDuplicateId() {
        Task task1 = new Task("12345", "First Task", "First Description");
        Task task2 = new Task("12345", "Second Task", "Second Description");
        
        taskService.addTask(task1);
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
        
        // Should still only have one task
        assertEquals(1, taskService.getTaskCount());
    }
    
    /*
     * Test successful deletion of a task
     */
    @Test
    public void testDeleteTaskSuccess() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertEquals(1, taskService.getTaskCount());
        
        taskService.deleteTask("12345");
        
        assertEquals(0, taskService.getTaskCount());
        assertNull(taskService.getTask("12345"));
    }
    
    /*
     * Test deleting a task with null ID throws exception
     */
    @Test
    public void testDeleteTaskWithNullId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask(null);
        });
    }
    
    /*
     * Test deleting a task that doesn't exist throws exception
     */
    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("99999");
        });
    }
    
    /*
     * Test successful update of task name
     */
    @Test
    public void testUpdateTaskNameSuccess() {
        Task task = new Task("12345", "Original Name", "Test Description");
        taskService.addTask(task);
        
        taskService.updateTaskName("12345", "Updated Name");
        
        Task updatedTask = taskService.getTask("12345");
        assertEquals("Updated Name", updatedTask.getName());
        assertEquals("Test Description", updatedTask.getDescription()); // Should remain unchanged
    }
    
    /*
     * Test updating task name with null ID throws exception
     */
    @Test
    public void testUpdateTaskNameWithNullId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName(null, "New Name");
        });
    }
    
    /*
     * Test updating task name for non-existent task throws exception
     */
    @Test
    public void testUpdateTaskNameNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("99999", "New Name");
        });
    }
    
    /*
     * Test updating task name to null throws exception
     */
    @Test
    public void testUpdateTaskNameToNull() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("12345", null);
        });
    }
    
    /*
     * Test updating task name to exceed character limit throws exception
     */
    @Test
    public void testUpdateTaskNameTooLong() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("12345", "123456789012345678901"); // 21 characters
        });
    }
    
    /*
     * Test successful update of task description
     */
    @Test
    public void testUpdateTaskDescriptionSuccess() {
        Task task = new Task("12345", "Test Task", "Original Description");
        taskService.addTask(task);
        
        taskService.updateTaskDescription("12345", "Updated Description");
        
        Task updatedTask = taskService.getTask("12345");
        assertEquals("Test Task", updatedTask.getName()); // Should remain unchanged
        assertEquals("Updated Description", updatedTask.getDescription());
    }
    
    /*
     * Test updating task description with null ID throws exception
     */
    @Test
    public void testUpdateTaskDescriptionWithNullId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription(null, "New Description");
        });
    }
    
    /*
     * Test updating task description for non-existent task throws exception
     */
    @Test
    public void testUpdateTaskDescriptionNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("99999", "New Description");
        });
    }
    
    /*
     * Test updating task description to null throws exception
     */
    @Test
    public void testUpdateTaskDescriptionToNull() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("12345", null);
        });
    }
    
    /*
     * Test updating task description to exceed character limit throws exception
     */
    @Test
    public void testUpdateTaskDescriptionTooLong() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("12345", "123456789012345678901234567890123456789012345678901"); // 51 characters
        });
    }
    
    /*
     * Test comprehensive workflow: add, update, and delete
     */
    @Test
    public void testCompleteWorkflow() {
        // Add a task
        Task task = new Task("12345", "Initial Task", "Initial Description");
        taskService.addTask(task);
        assertEquals(1, taskService.getTaskCount());
        
        // Update task name
        taskService.updateTaskName("12345", "Updated Task");
        assertEquals("Updated Task", taskService.getTask("12345").getName());
        
        // Update task description
        taskService.updateTaskDescription("12345", "Updated Description");
        assertEquals("Updated Description", taskService.getTask("12345").getDescription());
        
        // Delete the task
        taskService.deleteTask("12345");
        assertEquals(0, taskService.getTaskCount());
        assertNull(taskService.getTask("12345"));
    }
    
    /*
     * Test that task ID remains unchanged after updates
     */
    @Test
    public void testTaskIdRemainsUnchanged() {
        Task task = new Task("12345", "Test Task", "Test Description");
        taskService.addTask(task);
        
        String originalId = taskService.getTask("12345").getTaskId();
        
        // Update name and description
        taskService.updateTaskName("12345", "New Name");
        taskService.updateTaskDescription("12345", "New Description");
        
        // ID should remain the same
        assertEquals(originalId, taskService.getTask("12345").getTaskId());
    }
}