/*
 * Author: Justin Turner
 * Course: CS 320 - Software Test Automation & QA
 * Module Four Milestone - Task Service
 * File: TaskTest.java
 * Description: JUnit tests for the Task class to verify all requirements
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
    
    /*
     * Test successful creation of a Task object with valid parameters
     */
    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("12345", "Test Task", "This is a test description");
        
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description", task.getDescription());
    }
    
    /*
     * Test task creation with maximum allowed lengths
     */
    @Test
    public void testTaskCreationMaxLengths() {
        String maxId = "1234567890";        // 10 characters
        String maxName = "12345678901234567890"; // 20 characters
        String maxDesc = "12345678901234567890123456789012345678901234567890"; // 50 characters
        
        Task task = new Task(maxId, maxName, maxDesc);
        
        assertEquals(maxId, task.getTaskId());
        assertEquals(maxName, task.getName());
        assertEquals(maxDesc, task.getDescription());
    }
    
    /*
     * Test that task ID cannot be null
     */
    @Test
    public void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test Task", "Test Description");
        });
    }
    
    /*
     * Test that task ID cannot be longer than 10 characters
     */
    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test Task", "Test Description"); // 11 characters
        });
    }
    
    /*
     * Test that task name cannot be null
     */
    @Test
    public void testTaskNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Test Description");
        });
    }
    
    /*
     * Test that task name cannot be longer than 20 characters
     */
    @Test
    public void testTaskNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "123456789012345678901", "Test Description"); // 21 characters
        });
    }
    
    /*
     * Test that task description cannot be null
     */
    @Test
    public void testTaskDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", null);
        });
    }
    
    /*
     * Test that task description cannot be longer than 50 characters
     */
    @Test
    public void testTaskDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", "123456789012345678901234567890123456789012345678901"); // 51 characters
        });
    }
    
    /*
     * Test successful update of task name
     */
    @Test
    public void testUpdateTaskNameSuccess() {
        Task task = new Task("12345", "Old Name", "Test Description");
        task.setName("New Name");
        
        assertEquals("New Name", task.getName());
    }
    
    /*
     * Test that task name cannot be updated to null
     */
    @Test
    public void testUpdateTaskNameToNull() {
        Task task = new Task("12345", "Test Task", "Test Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
    }
    
    /*
     * Test that task name cannot be updated to exceed 20 characters
     */
    @Test
    public void testUpdateTaskNameTooLong() {
        Task task = new Task("12345", "Test Task", "Test Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("123456789012345678901"); // 21 characters
        });
    }
    
    /*
     * Test successful update of task description
     */
    @Test
    public void testUpdateTaskDescriptionSuccess() {
        Task task = new Task("12345", "Test Task", "Old Description");
        task.setDescription("New Description");
        
        assertEquals("New Description", task.getDescription());
    }
    
    /*
     * Test that task description cannot be updated to null
     */
    @Test
    public void testUpdateTaskDescriptionToNull() {
        Task task = new Task("12345", "Test Task", "Test Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }
    
    /*
     * Test that task description cannot be updated to exceed 50 characters
     */
    @Test
    public void testUpdateTaskDescriptionTooLong() {
        Task task = new Task("12345", "Test Task", "Test Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("123456789012345678901234567890123456789012345678901"); // 51 characters
        });
    }
    
    /*
     * Test that task ID is immutable (no setter method should exist)
     */
    @Test
    public void testTaskIdIsImmutable() {
        Task task = new Task("12345", "Test Task", "Test Description");
        String originalId = task.getTaskId();
        
        // Task ID should remain the same - there's no setTaskId method
        assertEquals(originalId, task.getTaskId());
    }
}